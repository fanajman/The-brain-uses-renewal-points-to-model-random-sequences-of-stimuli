function MyRunDissKS001
%% Path to the averaged data.
%base_rootdir = '/Users/pesquisador/Desktop/servidor/MATLAB/ExportFolder/Averaging_electrodes/';
base_rootdir = '/var/tmp/CopyOfData/MATLAB/NewAnalysis/KS001/Averaging_electrodesKS001/';
%% Create the dissimilarity matrix
DissimilarityMatrixKS001(base_rootdir)