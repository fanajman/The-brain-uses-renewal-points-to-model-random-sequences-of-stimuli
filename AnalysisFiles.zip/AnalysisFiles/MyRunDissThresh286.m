function MyRunDiss
%% Path to the averaged data.
%base_rootdir = '/Users/pesquisador/Desktop/servidor/MATLAB/ExportFolder/Averaging_electrodes/';
base_rootdir = '/var/tmp/CopyOfData/MATLAB/NewAnalysis/Thresh286/Averaging_electrodesThresh286/';
%% Create the dissimilarity matrix
DissimilarityMatrixThresh286(base_rootdir)