function MyRunDiss2Elecs
%% Path to the averaged data.
%base_rootdir = '/Users/pesquisador/Desktop/servidor/MATLAB/ExportFolder/Averaging_electrodes/';
base_rootdir = '/var/tmp/CopyOfData/MATLAB/NewAnalysis/DoisElecs/Averaging_electrodes2Elecs/';
%% Create the dissimilarity matrix
DissimilarityMatrix2Elecs(base_rootdir)