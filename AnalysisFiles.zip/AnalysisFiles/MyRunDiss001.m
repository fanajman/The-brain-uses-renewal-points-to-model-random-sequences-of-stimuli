function MyRunDiss001
%% Path to the averaged data.
%base_rootdir = '/Users/pesquisador/Desktop/servidor/MATLAB/ExportFolder/Averaging_electrodes/';
base_rootdir = '/var/tmp/CopyOfData/MATLAB/NewAnalysis/Cut001/Averaging_electrodes001/';
%% Create the dissimilarity matrix
DissimilarityMatrix001(base_rootdir)