function MyRunAvgSym
%% Path to the preprocessed data
%base_rootdir = '/Users/pesquisador/Desktop/servidor/MATLAB/ExportFolder/Pre-processed_data/';
base_rootdir = '/var/tmp/CopyOfData/MATLAB/NewAnalysis/PreProcess/';
%% Electrodes to be averaged. Each row is a cortical region.
ue = [10,11,18];

%% Quaternary or ternary conditions. Use 'qua' or 'ter' respectively.
cond = 'qua';

%% Run for each cortical region and each condition.
for ii = 1:1
    e = ue(ii, :);
    AvgElecs(base_rootdir,  e, cond);
end

cond = 'ter';
for ii = 1:1
    e = ue(ii, :);
    AvgElecs(base_rootdir,  e, cond);
end