function MyRunDissSym
%% Path to the averaged data.
%base_rootdir = '/Users/pesquisador/Desktop/servidor/MATLAB/ExportFolder/Averaging_electrodes/';
base_rootdir = '/var/tmp/CopyOfData/MATLAB/NewAnalysis/Sym/Averaging_electrodesSym/';
%% Create the dissimilarity matrix
DissimilarityMatrix(base_rootdir)